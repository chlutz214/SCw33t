# SCw33t
Chrome Extension to customize Service Cloud.
