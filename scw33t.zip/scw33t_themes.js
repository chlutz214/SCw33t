// SCw33t_themes.js
// Holds themes

  var themes = {

    Custom: { },

    SCPlus: {
      body_bg_color: '#FFFFFF',
      body_text_color: '#16325C',
      body_text_modified_color: '#FF6A00',
      body_link_color: '#006CB5',
      body_link_hover_color: '#FF0000',
      body_label_text_color: '#54698D',
    },

    Dark: {
      body_bg_color: '#000000',
      body_text_color: '#FFFFFF',
      body_text_modified_color: '#FF6A00',
      body_link_color: '#006CB5',
      body_link_hover_color: '#FF0000',
      body_label_text_color: '#54698D',
    }
  };
